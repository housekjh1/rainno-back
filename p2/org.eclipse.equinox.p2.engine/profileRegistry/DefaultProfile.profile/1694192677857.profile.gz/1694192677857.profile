<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1694192677857'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/Users/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e429/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.20.0.RELEASE'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Users/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e429/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.20.0.RELEASE'/>
  </properties>
</profile>
